// client/src/pages/operations/system-health/index.tsx
// System Health Test page — styled to match existing Operations pages
// (clean, modern, white background with yellow as an accent)

import { useEffect, useState } from "react";
import axios from "axios";

type HealthResults = {
  salesCreated: boolean;
  stockCreated: boolean;
  shoppingListGenerated: boolean;
  reportGenerated: boolean;
  jsonValid: boolean;
  pdfValid: boolean;
  listValid: boolean;
  errors?: string[];
};

type ApiResponse = {
  ok: boolean;
  results: HealthResults;
  reportId?: number;
};

const CHECKS: { key: keyof HealthResults; label: string }[] = [
  { key: "salesCreated",           label: "Daily Sales created" },
  { key: "stockCreated",           label: "Daily Stock submitted" },
  { key: "shoppingListGenerated",  label: "Shopping List generated" },
  { key: "reportGenerated",        label: "Daily Report compiled" },
  { key: "jsonValid",              label: "Report JSON valid" },
  { key: "pdfValid",               label: "Report PDF generated" },
  { key: "listValid",              label: "Report appears in list" },
];

function StatusBadge({ pass }: { pass: boolean }) {
  return (
    <span
      className={
        "inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold " +
        (pass
          ? "bg-emerald-100 text-emerald-700 border border-emerald-300"
          : "bg-red-100 text-red-700 border border-red-300")
      }
    >
      {pass ? "PASS" : "FAIL"}
    </span>
  );
}

export default function SystemHealthPage() {
  const [loading, setLoading] = useState(true);
  const [response, setResponse] = useState<ApiResponse | null>(null);

  useEffect(() => {
    let isMounted = true;

    async function runTest() {
      try {
        const res = await axios.get<ApiResponse>("/api/system-health/run");
        if (isMounted) {
          setResponse(res.data);
        }
      } catch (err) {
        if (isMounted) {
          setResponse({
            ok: false,
            results: {
              salesCreated: false,
              stockCreated: false,
              shoppingListGenerated: false,
              reportGenerated: false,
              jsonValid: false,
              pdfValid: false,
              listValid: false,
              errors: ["Request to /api/system-health/run failed"],
            },
          });
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    runTest();
    return () => {
      isMounted = false;
    };
  }, []);

  const results = response?.results;

  return (
    <div className="px-6 py-6">
      <div className="max-w-5xl mx-auto">
        {/* Page title */}
        <header className="mb-6">
          <h1 className="text-3xl font-extrabold font-[Poppins] text-gray-900">
            System Health Test
          </h1>
          <p className="mt-2 text-sm text-gray-600">
            This page runs a full end-to-end check of the Daily Sales → Daily Stock → Shopping List → Daily Report pipeline.
          </p>
        </header>

        {/* Overall status banner */}
        <section className="mb-6">
          <div className="rounded-lg border border-gray-200 bg-white shadow-sm">
            <div className="border-b border-gray-200 bg-yellow-300 px-4 py-3 rounded-t-lg">
              <p className="text-sm font-semibold text-gray-900">
                Test Status
              </p>
            </div>
            <div className="px-4 py-4">
              {loading && (
                <p className="text-sm text-gray-700">
                  Running system health test…
                </p>
              )}

              {!loading && results && (
                <div className="flex items-center justify-between flex-wrap gap-3">
                  <div className="flex flex-col">
                    <span className="text-sm text-gray-600">
                      Overall pipeline status
                    </span>
                    <span className="mt-1 text-lg font-semibold text-gray-900">
                      {response?.ok ? "All checks passed" : "One or more checks failed"}
                    </span>
                  </div>
                  <StatusBadge
                    pass={
                      !!(
                        results.salesCreated &&
                        results.stockCreated &&
                        results.shoppingListGenerated &&
                        results.reportGenerated &&
                        results.jsonValid &&
                        results.pdfValid &&
                        results.listValid
                      )
                    }
                  />
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Detailed checklist */}
        <section className="mb-6">
          <div className="rounded-lg border border-gray-200 bg-white shadow-sm">
            <div className="border-b border-gray-200 bg-gray-50 px-4 py-3 rounded-t-lg">
              <p className="text-sm font-semibold text-gray-900">
                Pipeline Checks
              </p>
            </div>

            <div className="px-4 py-4">
              {loading && (
                <p className="text-sm text-gray-700">
                  Gathering detailed results…
                </p>
              )}

              {!loading && results && (
                <table className="min-w-full text-sm">
                  <thead>
                    <tr className="text-left text-xs font-semibold text-gray-500">
                      <th className="py-2 pr-4">Step</th>
                      <th className="py-2 pr-4">Description</th>
                      <th className="py-2">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {CHECKS.map((check, idx) => (
                      <tr
                        key={check.key}
                        className={idx % 2 === 0 ? "bg-white" : "bg-gray-50"}
                      >
                        <td className="py-2 pr-4 text-gray-900">
                          {idx + 1}
                        </td>
                        <td className="py-2 pr-4 text-gray-800">
                          {check.label}
                        </td>
                        <td className="py-2">
                          <StatusBadge pass={!!results[check.key]} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </section>

        {/* Report info & links */}
        {response?.reportId && (
          <section className="mb-6">
            <div className="rounded-lg border border-gray-200 bg-white shadow-sm">
              <div className="border-b border-gray-200 bg-gray-50 px-4 py-3 rounded-t-lg">
                <p className="text-sm font-semibold text-gray-900">
                  Latest Test Report
                </p>
              </div>
              <div className="px-4 py-4 text-sm text-gray-800 flex flex-wrap items-center gap-3">
                <span>
                  Report ID:{" "}
                  <span className="font-mono font-semibold">
                    {response.reportId}
                  </span>
                </span>
                <a
                  href={`/api/reports/${response.reportId}/json`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center rounded border border-gray-300 px-3 py-1 text-xs font-semibold text-gray-800 hover:bg-gray-50"
                >
                  View JSON
                </a>
                <a
                  href={`/api/reports/${response.reportId}/pdf`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center rounded border border-yellow-400 bg-yellow-300 px-3 py-1 text-xs font-semibold text-gray-900 hover:bg-yellow-200"
                >
                  Download PDF
                </a>
              </div>
            </div>
          </section>
        )}

        {/* Error panel if any */}
        {results?.errors && results.errors.length > 0 && (
          <section className="mb-6">
            <div className="rounded-lg border border-red-300 bg-red-50 shadow-sm">
              <div className="border-b border-red-200 bg-red-100 px-4 py-3 rounded-t-lg">
                <p className="text-sm font-semibold text-red-800">
                  Errors
                </p>
              </div>
              <div className="px-4 py-4 text-xs text-red-800">
                <pre className="whitespace-pre-wrap break-words">
                  {JSON.stringify(results.errors, null, 2)}
                </pre>
              </div>
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
