export default function SaaSAdmin() {
  return (
    <div style={{ padding: 40 }}>
      <h1 style={{ fontSize: 32 }}>Multi-Tenant SaaS Mode (Coming Online)</h1>
      <p style={{ fontSize: 20 }}>
        Your system now supports multiple restaurants under a single dashboard.
        Smash Brothers Burgers is Tenant ID 1.
      </p>
    </div>
  );
}
