export default function DailyShiftForm() {
  return (
    <div className="p-4 md:p-6">
      <h1 className="text-xl font-semibold">Daily Shift Form</h1>
      <p className="text-sm text-gray-500">Placeholder page. Wire up later.</p>
    </div>
  );
}
